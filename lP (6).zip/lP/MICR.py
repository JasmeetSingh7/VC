import cv2
import pytesseract
from PIL import Image
import re
pytesseract.pytesseract.tesseract_cmd = r"Tesseract-OCR\tesseract.exe"
def p(path):
    img=cv2.imread(path)
    custom_config=r'--oem 3 --psm 6'
    text=pytesseract.image_to_string(img, lang='e13b',
config=custom_config)
    number_extract_pattern = "\D"
    x=re.sub(number_extract_pattern, "", text)
    print(x[-28:-19])
    return text
p("Capture.png")