import cv2
import matplotlib.pyplot as plt
import numpy as np
from signature_detect.loader import Loader