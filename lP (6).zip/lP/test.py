import pytesseract
def p(path):
    print(path)
    return path
p("y")
