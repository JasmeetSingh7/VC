import cv2
import pytesseract
from PIL import Image
import re
pytesseract.pytesseract.tesseract_cmd = r"C:\ProgramData\Tesseract-OCR\tesseract.exe"
def p(path):
    img=cv2.imread(path)
    text=pytesseract.image_to_string(img)
    number_extract_pattern = "\D"
    x=re.sub(number_extract_pattern, "", text)
    print(text)
    return x[-28:-19]
p("Test.png")